import React from 'react'



function Header(){


    return(
        <div className="header1">
            <h1>FoodInfomizer</h1>
        </div>
    )
}

export default Header